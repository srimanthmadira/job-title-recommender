from flask import Flask, render_template, request
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Initialize Flask app
app = Flask(__name__)

# Load and prepare the dataset
data_cleaned = pd.read_csv('data/job_data.csv')
data_cleaned['combined_features'] = data_cleaned['skills'] + ' ' + data_cleaned['jobdescription']
data_cleaned['skills'] = data_cleaned['skills'].fillna('')
data_cleaned['combined_features'] = data_cleaned['combined_features'].fillna('')

# Initialize TF-IDF Vectorizer
vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = vectorizer.fit_transform(data_cleaned['combined_features'])

# Job Recommendation Function
def recommend_jobs(input_skills, threshold=25):
    input_skills_list = {skill.strip().lower() for skill in input_skills.split(',')}
    input_vector = vectorizer.transform([input_skills])
    cosine_sim = cosine_similarity(input_vector, tfidf_matrix)
    
    matched_jobs = []
    for idx, row in data_cleaned.iterrows():
        job_title = row['jobtitle']
        job_skills = row['skills'].lower().split(',')
        job_skills = [skill.strip() for skill in job_skills]
        
        matching_skills = input_skills_list.intersection(job_skills)
        user_match_percentage = (len(matching_skills) / len(input_skills_list)) * 100 if input_skills_list else 0
        required_match_percentage = (len(matching_skills) / len(job_skills)) * 100 if job_skills else 0
        other_required_skills = set(job_skills) - matching_skills
        
        if user_match_percentage >= threshold:
            matched_jobs.append({
                'jobtitle': job_title,
                'user_match_percentage': user_match_percentage,
                'required_match_percentage': required_match_percentage,
                'other_required_skills': ', '.join(other_required_skills)
            })

    matched_jobs = sorted(matched_jobs, key=lambda x: x['user_match_percentage'], reverse=True)
    recommended_jobs = pd.DataFrame(matched_jobs).drop_duplicates(subset=['jobtitle'])
    return recommended_jobs

# Route for home page
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        input_skills = request.form['skills']
        recommended_jobs = recommend_jobs(input_skills)
        return render_template('index.html', recommended_jobs=recommended_jobs.to_dict(orient='records'))
    return render_template('index.html', recommended_jobs=None)

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
